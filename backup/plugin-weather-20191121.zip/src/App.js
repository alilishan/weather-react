import React, { Component } from 'react';
import Weather from './components/Weather';
import Forecast from './components/Forecast';

// import logo from './logo.svg';
// import './App.css';


// const getWeather = () => 
// 	fetch("https://jsonplaceholder.typicode.com/users")
// 	    .then(res => (res.ok ? res : Promise.reject(res)))
// 	    .then(res => res.json())


class App extends Component {

	constructor(props) {
		super(props);
		
		this.state = {
			isLoading: true,
			hasErrors: false,
			data: {}
		};
	}


	componentDidMount() {
		// https://dev.screenplify.it/dev_plugins/weather3.0/2.0/api/getWeather-mock.php?component_id=1
		this.getWeather();
	}



	getWeather = async() => {

	 	try {
			const resp = await fetch("https://www.screenplify.com/api/weather/getWeather-mock.php");
			const data = await resp.json();
	 		
			await this.setState({ 
				isLoading: false, 
				data: data 
			});

	 	} catch (e) {
	 		console.log(e);
			this.setState({ 
				isLoading: false, 
				hasErrors: true 
			});
	 	}

	}


	render(){
		const {isLoading, hasErrors, data} = this.state;

		if(isLoading)
			return ( <div className="alert alert-info">Loading ... </div> );

		if(hasErrors && !isLoading)
			return ( <div className="alert alert-danger">Error</div> );

		if(!isLoading && !hasErrors) {
			return ( 
				<div className="container-fluid">
					<div className="row">
						<div className="col-5">
							<Weather data={data} />
						</div>

						<div className="col-7 align-self-center">
							<Forecast data={data} />
						</div>
					</div>
				</div>
			)	
		}
	}


}

export default App;
