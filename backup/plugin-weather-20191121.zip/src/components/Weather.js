import React, { Component } from 'react';
import Moment from 'react-moment';
import Icon from './Icon';

class Weather extends Component {

	constructor(props) {
		super(props);
		
		this.state = {
			condition: props.data.current_observation.condition,
			forecasts: props.data.forecasts
		};

		// console.log(this.state);
	}


	componentDidMount() {
		this.getDate();
	}


	getDate = () => {
		// Setinterval to update
		this.setState({
			todayDate: new Date()
		});
	}


	render(){
		return (
			<div className="text-center">
				<Icon size={128} color='#333' code={this.state.condition.code} />
				<p className="lead m-0 p-0">{this.state.condition.text}</p>
				<hr />
				<p className="lead text-uppercase">
					<Moment format="dddd, MMM DD" >{this.state.condition.todayDate}</Moment>
				</p>
				<div className="display-2">{this.state.condition.temperature}  &deg; C</div>
				<p className="py-3">
					<span className="pr-2 font-weight-bold">H</span>
					<span className="pr-2">{this.state.forecasts[0].high}&deg;</span>
					<span className="px-3 font-weight-bold">L</span>
					<span className="pr-2">{this.state.forecasts[0].low}&deg;</span>
				</p>
			</div>
		)
	}

}

export default Weather;
